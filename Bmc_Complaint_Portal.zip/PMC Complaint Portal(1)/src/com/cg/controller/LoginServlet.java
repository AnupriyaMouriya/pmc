package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dao.ILoginDAO;
import com.cg.dao.LoginDAO;
import com.cg.entity.UserRole;
import com.cg.exceptions.PMCException;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String userId = request.getParameter("userId");
		String enteredPassword = request.getParameter("password");
		UserRole userRole = null;
		ILoginDAO iLoginDAO = new LoginDAO();
		HttpSession session = null;
		try 
		{
			userRole = iLoginDAO.login(userId);
		}
		catch (PMCException e) 
		{
			response.getWriter().println("<script> alaert('Invalid userId');</script>");
			request.getRequestDispatcher("Login.jsp").include(request, response);
		}
		if(userRole==null)
		{
			request.setAttribute("invalidCredentials", "Invalid user id or password");
			request.getRequestDispatcher("Login.jsp").forward(request, response);
		}
		System.out.println("1");
		String password = userRole.getPassword();
		if(password.equals(enteredPassword))
		{System.out.println("2");
			if(userRole.getUserRole().equals("citizen"))
			{	System.out.println("3");
				if(session == null)
					session = request.getSession();
				System.out.println("4");
				System.out.println(session.getAttribute("citizenLoggedIn"));
				System.out.println(userRole.getUserName());
				session.setAttribute("user", userRole);
				session.setAttribute("citizenLoggedIn",userRole.getUserName());
				System.out.println(session.getAttribute("citizenLoggedIn"));

				request.getRequestDispatcher("CitizenHomePage.jsp").forward(request, response);
			}
			else
			{
				if(session==null)
					session=request.getSession();
				session.setAttribute("employeeLoggedIn", userRole.getUserName());
				request.getRequestDispatcher("PMCEmployeeHomePage.jsp").forward(request, response);
			}
		}
		else
		{
			request.setAttribute("invalidCredentials", "Invalid user id or password");
			request.getRequestDispatcher("Login.jsp").forward(request, response);
		}
	}
}