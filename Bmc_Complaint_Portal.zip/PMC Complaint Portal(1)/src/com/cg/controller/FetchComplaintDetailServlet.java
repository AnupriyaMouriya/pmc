package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.ComplaintDAO;
import com.cg.dao.IComplaintDAO;
import com.cg.dao.IWorkerDAO;
import com.cg.dao.WorkerDAO;
import com.cg.entity.Complaint;
import com.cg.entity.Worker;

@WebServlet("/FetchComplaintDetailServlet")
public class FetchComplaintDetailServlet extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		int complaintId = Integer.parseInt(request.getParameter("complaintId"));
		
		IComplaintDAO complaintDAO = new ComplaintDAO();
		Complaint complaint = complaintDAO.viewComplaint(complaintId);
		
		IWorkerDAO workerDAO = new WorkerDAO();
		List<Worker> areaWorkers = workerDAO.viewAreawiseWorker(complaint.getArea());
		request.setAttribute("areaWorkers", areaWorkers);
		request.setAttribute("complaint", complaint);
		request.getRequestDispatcher("EmployeeUpdateComplaint.jsp").forward(request, response);
	}
}
