package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dao.ComplaintDAO;
import com.cg.dao.IComplaintDAO;
import com.cg.entity.Complaint;
import com.cg.entity.UserRole;

@WebServlet("/CitizenViewComplaintServlet")
public class CitizenViewComplaintServlet extends HttpServlet 
{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session = request.getSession();
		UserRole user = (UserRole)session.getAttribute("user");
		if(user!=null)
		{
		IComplaintDAO complaintDAO = new ComplaintDAO();
		List<Complaint> complaints = complaintDAO.viewCitizenWiseComplaint(user.getUserId());
		System.out.println(complaints);
		request.setAttribute("userComplaints", complaints);
		request.getRequestDispatcher("ViewComplaints.jsp").forward(request, response);
		}
	}
}
