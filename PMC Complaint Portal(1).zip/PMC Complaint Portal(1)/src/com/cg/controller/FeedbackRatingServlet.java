package com.cg.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.ComplaintDAO;
import com.cg.dao.IComplaintDAO;
import com.cg.entity.Complaint;
@WebServlet("/FeedbackRatingServlet")
public class FeedbackRatingServlet extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		int complaintId = Integer.parseInt(request.getParameter("complaintId"));
		String feedback = request.getParameter("feedback");
		float rating = Float.parseFloat(request.getParameter("rating"));
		
		Complaint complaint = new Complaint();
		complaint.setComplaintId(complaintId);
		complaint.setFeedBack(feedback);
		complaint.setRating(rating);
		
		IComplaintDAO complaintDAO = new ComplaintDAO();
		complaintDAO.giveFeedbackRating(complaint);
		
		response.getWriter().println("<script>alert('Feedback submitted successfully')</script>");
		request.getRequestDispatcher("CitizenHomePage.jsp").include(request, response);
		
	}
}
