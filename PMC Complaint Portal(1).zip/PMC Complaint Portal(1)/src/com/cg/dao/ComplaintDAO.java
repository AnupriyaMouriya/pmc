package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import com.cg.entity.Complaint;
import com.cg.utility.JPAUtility;

public class ComplaintDAO implements IComplaintDAO 
{
	static EntityManagerFactory factory = JPAUtility.getFactory();
	@Override
	public void registerComplaint(Complaint complaint) {
		
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		
		transaction.begin();
		try
		{
			manager.persist(complaint);
			transaction.commit();
		}
		catch (PersistenceException e)
		{
			e.printStackTrace();
		}
		finally 
		{
			manager.close();
//			factory.close();
		}
	}
	
	@Override
	public List<Complaint> viewAreawiseComplaint(String area) {
		List<Complaint> complaints = new ArrayList<Complaint>();
		
		EntityManager manager = factory.createEntityManager();
		
		TypedQuery<Complaint> query = manager.createQuery("select c from Complaint c where c.area='"+area+"'", Complaint.class);
		complaints = query.getResultList();
		return complaints;
	}

	@Override
	public Complaint viewComplaint(int complaintId) 
	{
		EntityManager manager = factory.createEntityManager();
		Complaint complaint = manager.find(Complaint.class, complaintId);
		return complaint;
	}

	@Override
	public void updateComplaint(Complaint complaint) 
	{
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		if(complaint.getComplaintStatus().equals("Pending"))
			complaint.setComplaintStatus("In Process");
		
		Complaint oldComplaint = manager.find(Complaint.class, complaint.getComplaintId());
		oldComplaint.setComplaintStatus(complaint.getComplaintStatus());
		oldComplaint.setWorkerId(complaint.getWorkerId());
		manager.persist(oldComplaint);
		transaction.commit();
		manager.close();
	}

	@Override
	public List<Complaint> viewCitizenWiseComplaint(String userId) 
	{
		EntityManager manager = factory.createEntityManager();
		TypedQuery<Complaint> complaints = manager.createQuery("select c from Complaint c where c.userId='"+userId+"'", Complaint.class);
		return complaints.getResultList();
	}

	@Override
	public void giveFeedbackRating(Complaint complaint) 
	{
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		
		Complaint oldComplaint = manager.find(Complaint.class, complaint.getComplaintId());
		oldComplaint.setFeedBack(complaint.getFeedBack());
		oldComplaint.setRating(complaint.getRating());
		manager.persist(oldComplaint);
		
		transaction.commit();
		manager.close();
	}

}
