package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;

import com.cg.entity.UserRole;
import com.cg.utility.JPAUtility;

public class SignUpDAO implements ISignUpDAO
{

	@Override
	public void addUser(UserRole userole) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory=JPAUtility.getFactory();
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		transaction.begin();
		try {
		manager.persist(userole);
		transaction.commit();
		}
		catch(PersistenceException e){
			System.out.println(e.getMessage());
			//e.printStackTrace();	
		}
		finally {
			manager.close();
//			factory.close();
		}
	}

}