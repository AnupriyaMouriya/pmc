package com.cg.dao;

import java.util.List;

import com.cg.entity.Worker;

public interface IWorkerDAO 
{
	List<Worker> viewAreawiseWorker(String area);
}
