package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceException;

import com.cg.entity.UserRole;
import com.cg.exceptions.PMCException;
import com.cg.utility.JPAUtility;

public class LoginDAO implements ILoginDAO
{

	@Override
	public UserRole login(String userId) throws PMCException 
	{
		EntityManagerFactory factory = JPAUtility.getFactory();
		EntityManager manager = factory.createEntityManager();
		UserRole userRole = null;
		try
		{
			userRole = manager.find(UserRole.class,userId);
		}
		catch(PersistenceException e)
		{
			throw new PMCException(e.getMessage());
		}
		finally {
			manager.close();
		}
		return userRole;
	}

}
