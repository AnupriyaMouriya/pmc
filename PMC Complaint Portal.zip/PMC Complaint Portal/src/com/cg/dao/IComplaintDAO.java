package com.cg.dao;

import java.util.List;

import com.cg.entity.Complaint;

public interface IComplaintDAO {

	void registerComplaint(Complaint complaint);

	List<Complaint> viewAreawiseComplaint(String area);
}
