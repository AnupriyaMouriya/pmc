package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import com.cg.entity.Complaint;
import com.cg.exceptions.PMCException;
import com.cg.utility.JPAUtility;

public class ComplaintDAO implements IComplaintDAO{

	@Override
	public void registerComplaint(Complaint complaint) {
		// TODO Auto-generated method stub
		EntityManagerFactory factory=JPAUtility.getFactory();
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		transaction.begin();
		try {
		manager.persist(complaint);
		transaction.commit();
		}
		catch(PersistenceException e){
			System.out.println(e.getMessage());
			e.printStackTrace();	
		}
		finally {
			factory.close();
		}
	}

	@Override
	public List<Complaint> viewAreawiseComplaint(String area) {
		List<Complaint> complaints = new ArrayList<Complaint>();
		EntityManagerFactory factory = JPAUtility.getFactory();
		EntityManager manager = factory.createEntityManager();
		
		TypedQuery<Complaint> query = manager.createQuery("select c from Complaint c where c.area='"+area+"'", Complaint.class);
		complaints = query.getResultList();
		return complaints;
	}

}
