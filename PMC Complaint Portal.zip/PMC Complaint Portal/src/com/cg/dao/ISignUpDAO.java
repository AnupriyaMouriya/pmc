package com.cg.dao;

import com.cg.entity.UserRole;

public interface ISignUpDAO {
void addUser(UserRole userole);
}
