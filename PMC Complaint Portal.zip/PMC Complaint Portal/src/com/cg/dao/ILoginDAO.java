package com.cg.dao;

import com.cg.entity.UserRole;
import com.cg.exceptions.PMCException;

public interface ILoginDAO {
UserRole login(String userId) throws PMCException;
}
