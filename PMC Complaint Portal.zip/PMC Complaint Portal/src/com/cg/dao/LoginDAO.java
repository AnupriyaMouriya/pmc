package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;

import com.cg.entity.UserRole;
import com.cg.exceptions.PMCException;
import com.cg.utility.JPAUtility;

public class LoginDAO implements ILoginDAO{

	@Override
	public UserRole login(String userId) throws PMCException {
		// TODO Auto-generated method stub
		EntityManagerFactory factory=JPAUtility.getFactory();
		EntityManager manager=factory.createEntityManager();
		EntityTransaction transaction=manager.getTransaction();
		UserRole userRole=null;
		transaction.begin();
		try
		{
			userRole=manager.find(UserRole.class, userId);
		}
		catch(PersistenceException e) {
			throw new PMCException(e.getMessage());
		}
		return userRole;
	}

}
