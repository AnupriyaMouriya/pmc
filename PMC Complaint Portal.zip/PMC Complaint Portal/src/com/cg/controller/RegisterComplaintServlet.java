package com.cg.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dao.ComplaintDAO;
import com.cg.dao.IComplaintDAO;
import com.cg.entity.Complaint;
import com.cg.entity.UserRole;

@WebServlet("/RegisterComplaintServlet")
public class RegisterComplaintServlet extends HttpServlet {
@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub
	String complaintDetails=request.getParameter("complaintDetails");
	HttpSession session=request.getSession();
	UserRole userRole=(UserRole) session.getAttribute("user");
	String userId=userRole.getUserId();
	String area=userRole.getArea();
	Complaint complaint=new Complaint(userId,complaintDetails,area);
	System.out.println(complaint);
	IComplaintDAO iComplaintDAO=new ComplaintDAO();
	iComplaintDAO.registerComplaint(complaint);
}
}
