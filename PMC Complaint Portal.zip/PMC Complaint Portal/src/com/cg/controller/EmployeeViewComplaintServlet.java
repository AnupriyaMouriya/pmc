package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.ComplaintDAO;
import com.cg.dao.IComplaintDAO;
import com.cg.entity.Complaint;

@WebServlet("/EmployeeViewComplaintServlet")
public class EmployeeViewComplaintServlet extends HttpServlet{
@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	// TODO Auto-generated method stub
	String area=request.getParameter("area");
	IComplaintDAO iComplaintDAO=new ComplaintDAO();
	List<Complaint> complaint=iComplaintDAO.viewAreawiseComplaint(area);
    System.out.println(complaint);
    request.setAttribute("areaWiseComplaint", complaint); 
    request.getRequestDispatcher("PMCEmployeeHomePage.jsp").forward(request,response);
}
}
