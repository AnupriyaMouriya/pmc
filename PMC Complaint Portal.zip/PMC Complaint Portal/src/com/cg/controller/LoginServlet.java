package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dao.ILoginDAO;
import com.cg.dao.LoginDAO;
import com.cg.entity.UserRole;
import com.cg.exceptions.PMCException;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet
{
	//private static final long serialVersionUID = 1L;
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String userId = request.getParameter("userId");
		String enteredPassword = request.getParameter("password");
		UserRole userRole = null;
		ILoginDAO iLoginDAO = new LoginDAO();
		HttpSession session = null;
		try 
		{
			userRole = iLoginDAO.login(userId);
		}
		catch (PMCException e) 
		{
			e.printStackTrace();
		}
		String password = userRole.getPassword();
		if(password.equals(enteredPassword))
		{
			if(userRole.getUserRole().equals("citizen"))
			{
				if(session == null)
					session = request.getSession();
				session.setAttribute("user", userRole);
				
				request.getRequestDispatcher("CitizenHomePage.jsp").forward(request, response);
			}
			else
			{
				request.getRequestDispatcher("PMCEmployeeHomePage.jsp").forward(request, response);
			}
		}
		else
		{
			response.getWriter().println("<script> alaert('Invalid credentials');</script>");
		}
	}
}