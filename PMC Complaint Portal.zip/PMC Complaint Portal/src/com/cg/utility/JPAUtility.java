package com.cg.utility;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtility {

	static EntityManagerFactory factory = null;

	static {
		System.out.print("okokokokok");
		factory = Persistence.createEntityManagerFactory("PMC_pu");
		System.out.print("okokokokok");
	}

	public static EntityManagerFactory getFactory() {
		return factory;
	}

}

