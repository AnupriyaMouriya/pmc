package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.CascadeType;

@Entity
public class Complaint 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int complaintId;
	//@ManyToOne(cascade = CascadeType.ALL)
	//@JoinColumn(name = "userId",referencedColumnName="userId")
	private String  userId;
	private String complaintDetails;
	//@JoinColumn(name = "area", referencedColumnName = "area")
	private String area;
	private String complaintStatus;
	private Float rating;
	private String feedBack;
    private String workerId;	
	public Complaint(String userId, String complaintDetails, String area) {
		super();
		this.userId = userId;
		this.complaintDetails = complaintDetails;
		this.area = area;
		this.complaintStatus="pending";
	}

	public Complaint(int complaintId, String userId, String complaintDetails, String area, String complaintStatus,
			Float rating, String feedBack, String workerId) {
		super();
		this.complaintId = complaintId;
		this.userId = userId;
		this.complaintDetails = complaintDetails;
		this.area = area;
		this.complaintStatus = complaintStatus;
		this.rating = rating;
		this.feedBack = feedBack;
		this.workerId = workerId;
	}

	public int getComplaintId() {
		return complaintId;
	}

	public void setComplaintId(int complaintId) {
		this.complaintId = complaintId;
	}
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getComplaintDetails() {
		return complaintDetails;
	}

	public void setComplaintDetails(String complaintDetails) {
		this.complaintDetails = complaintDetails;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getComplaintStatus() {
		return complaintStatus;
	}

	public void setComplaintStatus(String complaintStatus) {
		this.complaintStatus = complaintStatus;
	}

	public Float getRating() {
		return rating;
	}

	public void setRating(Float rating) {
		this.rating = rating;
	}

	public String getFeedBack() {
		return feedBack;
	}

	public void setFeedBack(String feedBack) {
		this.feedBack = feedBack;
	}

	public String getWorkerId() {
		return workerId;
	}

	public void setWorkerId(String workerId) {
		this.workerId = workerId;
	}


	@Override
	public String toString() {
		return "Complaint [complaintId=" + complaintId + ", userId=" + userId + ", complaintDetails=" + complaintDetails
				+ ", area=" + area + ", complaintStatus=" + complaintStatus + ", rating=" + rating + ", feedBack="
				+ feedBack + ", workerId=" + workerId + "]";
	}

	public Complaint() {
		super();
	}

	
	
}
